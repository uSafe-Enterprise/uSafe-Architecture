package os.amber.designsystem.theme
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
private val Colors=darkColorScheme(primary=AmberSand,onPrimary=AmberBase,secondary=Cobalt,tertiary=Sage,error=Terracotta,background=AmberBase,onBackground=TextPrimary,surface=AmberSurface,onSurface=TextPrimary,outline=AmberBorder)
@Composable fun AmberOSTheme(content:@Composable()->Unit){ MaterialTheme(colorScheme=Colors,content=content) }

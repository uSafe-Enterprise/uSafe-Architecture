package os.amber.designsystem.theme
import androidx.compose.ui.graphics.Color
val AmberCanvas=Color(0xFF0E0E10); val AmberBase=Color(0xFF121214); val AmberSurface=Color(0xFF181A1F); val AmberSlate=Color(0xFF1C1E22); val AmberBorder=Color(0xFF2A2E35)
val AmberSand=Color(0xFFDDA15E); val AmberDeep=Color(0xFFBC6C25); val Sage=Color(0xFF52B788); val SageDeep=Color(0xFF2D6A4F); val Cobalt=Color(0xFF4A6FA5); val CobaltDeep=Color(0xFF2E4057); val Terracotta=Color(0xFFE07A5F); val Danger=Color(0xFFC44536); val TextPrimary=Color(0xFFF4F4F9); val TextSecondary=Color(0xFF8D99AE); val Metadata=Color(0xFF6E7681)

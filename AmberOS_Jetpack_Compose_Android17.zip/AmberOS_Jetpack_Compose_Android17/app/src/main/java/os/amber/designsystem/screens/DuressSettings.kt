package os.amber.designsystem.screens
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import os.amber.designsystem.components.*
import os.amber.designsystem.theme.*
@Composable fun DuressSettings(){var decoy by remember{mutableStateOf(true)};Column(Modifier.fillMaxSize().padding(20.dp),verticalArrangement=Arrangement.spacedBy(14.dp)){Text("Duress & Emergency",style=MaterialTheme.typography.headlineMedium);Text("Configure a separate emergency response credential.",color=TextSecondary);Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween){Column{Text("Decoy Workspace");Text("Open an isolated decoy profile",color=TextSecondary)};AmberToggle(decoy){decoy=it}};PrivacyCard("Emergency Wipe","Optional destructive response; require explicit setup and confirmation.","Disabled",Terracotta);Text("Never reuse your primary screen-lock credential.",color=Terracotta)}}

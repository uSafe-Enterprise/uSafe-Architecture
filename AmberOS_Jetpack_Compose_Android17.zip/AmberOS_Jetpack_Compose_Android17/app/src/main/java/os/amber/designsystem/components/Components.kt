package os.amber.designsystem.components
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import os.amber.designsystem.theme.*
enum class AmberButtonStyle{Primary,Secondary,Danger}
@Composable fun AmberButton(text:String,onClick:()->Unit,modifier:Modifier=Modifier,style:AmberButtonStyle=AmberButtonStyle.Primary){val bg=when(style){AmberButtonStyle.Primary->AmberSand;AmberButtonStyle.Secondary->AmberSlate;AmberButtonStyle.Danger->Terracotta};Button(onClick,modifier.height(48.dp),shape=RoundedCornerShape(27.dp),colors=ButtonDefaults.buttonColors(containerColor=bg,contentColor=if(style==AmberButtonStyle.Secondary)TextPrimary else AmberBase)){Text(text)}}
@Composable fun AmberToggle(checked:Boolean,onChange:(Boolean)->Unit)=Switch(checked,onChange,colors=SwitchDefaults.colors(checkedTrackColor=AmberSand,checkedThumbColor=TextPrimary,uncheckedTrackColor=AmberBorder))
@Composable fun PrivacyCard(title:String,description:String,status:String,color:androidx.compose.ui.graphics.Color=Sage){Column(Modifier.fillMaxWidth().background(AmberSurface,RoundedCornerShape(16.dp)).border(1.dp,AmberBorder,RoundedCornerShape(16.dp)).padding(16.dp)){Text(title,color=TextPrimary);Spacer(Modifier.height(6.dp));Text(description,color=TextSecondary);Spacer(Modifier.height(10.dp));Text(status.uppercase(),color=color)}}

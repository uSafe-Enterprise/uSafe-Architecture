package os.amber.designsystem.screens
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import os.amber.designsystem.components.*
import os.amber.designsystem.theme.*
@Composable fun PrivacyDashboard(){Column(Modifier.fillMaxSize().padding(20.dp),verticalArrangement=Arrangement.spacedBy(12.dp)){Text("Privacy",style=MaterialTheme.typography.headlineMedium);PrivacyCard("uGuard Multi-Hop Relay","Encrypted traffic routed through isolated relay hops.","Zurich Relay · Active");PrivacyCard("Location Virtualizer","Per-app coarse positioning with randomized offset.","~5 km randomized",Cobalt);PrivacyCard("Baseband Stealth","Cellular privacy controls and downgrade protection.","2G downgrade blocked");PrivacyCard("Sensor Access","Camera, microphone, clipboard and location history.","Review permissions")}}

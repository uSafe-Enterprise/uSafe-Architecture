package os.amber.designsystem.screens
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import os.amber.designsystem.components.*
import os.amber.designsystem.theme.*
@Composable fun USafeEnclaveSheet(onCancel:()->Unit,onVerify:()->Unit){Column(Modifier.fillMaxWidth().padding(24.dp),verticalArrangement=Arrangement.spacedBy(16.dp)){Text("uSafe ENCLAVE",color=Metadata);Text("Authenticate with Passkey",style=MaterialTheme.typography.titleLarge);Text("Credential verification is hardware rooted.",color=TextSecondary);Row(horizontalArrangement=Arrangement.spacedBy(12.dp)){AmberButton("Cancel",onCancel,Modifier.weight(1f),AmberButtonStyle.Secondary);AmberButton("Verify",onVerify,Modifier.weight(1f))}}}

# Amber OS Jetpack Compose — Android 17
Compose UI reference matching the Amber OS vector system.

Includes OLED dark theme tokens, flat high-contrast controls, privacy dashboard, uGuard relay UI, Location Virtualizer, Baseband Stealth, duress/emergency settings, and uSafe passkey/enclave sheet.

Security, telephony, wipe, location and enclave behaviors are UI specifications and must be connected only to supported Android/OEM APIs with appropriate authorization.

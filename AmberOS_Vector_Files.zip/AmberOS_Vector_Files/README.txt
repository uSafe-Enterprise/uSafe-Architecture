Amber OS Android 17 vector files

Included:
- Amber hexagon brand mark
- Crisp system glyphs: Wi-Fi, shield, lock, location, moon, fingerprint, relay, GPS masking, baseband lock, wipe, decoy, warning, chat
- Flat app icons: uChat, uPay, Enclave, Kite
- Privacy dashboard
- uGuard multi-hop relay card
- Location Virtualizer card
- Baseband Stealth card
- Duress Mode configuration card
- uSafe Enclave passkey modal
- Hexagon loading indicator

Palette:
#0E0E10 canvas
#121214 base
#181A1F surface
#2A2E35 border
#DDA15E amber
#BC6C25 deep amber
#52B788 sage
#2D6A4F deep sage
#4A6FA5 cobalt
#2E4057 deep cobalt
#E07A5F terracotta
#C44536 danger
#F4F4F9 primary text
#8D99AE secondary text

All files are editable SVG geometry with no embedded raster images.
